﻿Public Class Form1
    'Aleksander Chrismer
    'String manipulation example


    Private Sub btnVowels_Click(sender As Object, e As EventArgs) Handles btnVowels.Click
        Dim strSentence As String
        Dim intVowelCount As Integer

        Dim blnValidated As Boolean = True

        Validate_Sentence(strSentence, blnValidated)

        If blnValidated Then

            intVowelCount = CountVowels(strSentence)
            Display_VowelCount(intVowelCount)
        End If

    End Sub



    Private Function CountVowels(ByVal strSentence As String) As Integer
        Dim intStringLength As Integer
        Dim intVowelCount As Integer
        Dim intIndex As Integer
        Dim strCharacter As String



        'determine length of string
        intStringLength = strSentence.Length

        ' loop through the string looking at each character to determine if is a vowel 
        '  pull the character using substring


        For intIndex = 0 To intStringLength - 1
            strCharacter = strSentence.Substring(intIndex, 1)
            If (strCharacter.ToUpper = "A") Or (strCharacter.ToUpper = "E") Or (strCharacter.ToUpper = "I") Or (strCharacter.ToUpper = "O") Or (strCharacter.ToUpper = "U") Then
                intVowelCount += 1
            End If
        Next

        Return intVowelCount
    End Function

    Private Sub Display_VowelCount(ByVal intVowelCount As Integer)
        MessageBox.Show("Total Vowels are " & intVowelCount)
    End Sub

    Private Sub btnWords_Click(sender As Object, e As EventArgs) Handles btnWords.Click
        Dim strSentence As String
        Dim intWordCount As Integer
        'count the words

        Dim blnValidated As Boolean = True

        Validate_Sentence(strSentence, blnValidated)

        If blnValidated Then

            intWordCount = CountWords(strSentence)
            Display_WordCount(intWordCount)
        End If
    End Sub

    Private Sub Validate_Sentence(ByRef strSentence As String, ByRef blnValidated As Boolean)
        'validate sentence input

        If txtSentence.Text = "" Then
            MessageBox.Show("Sentence Must be Provided")
            txtSentence.Focus()
            blnValidated = False
        Else
            strSentence = txtSentence.Text
        End If
    End Sub

    Private Function CountWords(ByVal strSentence As String) As Integer
        Dim intStringLength As Integer
        Dim intWordCount As Integer
        Dim intIndex As Integer
        Dim strCharacter As String

        ' Trim spaces before and after  

        strSentence = strSentence.Trim


        ' get length of the string

        intStringLength = strSentence.Length

        For intIndex = 0 To intStringLength - 1
            strCharacter = strSentence.Substring(intIndex, 1)
            If (strCharacter.ToUpper = " ") Then
                intWordCount += 1
            End If
        Next

        intWordCount += 1

        Return intWordCount
    End Function

    Private Sub Display_WordCount(ByVal intWordCount As Integer)
        MessageBox.Show("Total Words are " & intWordCount)
    End Sub

    Private Sub btnBreakApart_Click(sender As Object, e As EventArgs) Handles btnBreakApart.Click
        Dim strRecord As String
        Dim intWordCount As Integer

        Dim blnValidated As Boolean = True

        Validate_Record(strRecord, blnValidated)

        If blnValidated Then
            BreakApartRecord(strRecord)
        End If
    End Sub

    Private Sub Validate_Record(ByRef strRecord As String, ByRef blnValidated As Boolean)
        'validate record input
        If txtRecord.Text = "" Then
            MessageBox.Show("Record Must be Provided")
            txtRecord.Focus()
            blnValidated = False
        Else
            strRecord = txtRecord.Text
        End If
    End Sub


    Private Sub BreakApartRecord(ByVal strRecord As String)

        Dim intCount As Integer = 1
        Dim intIndex As Integer





        ' find where comma is then pull the word
        ' 
        intIndex = strRecord.IndexOf(",")

        Do Until intIndex = -1

            Select Case intCount
                Case 1
                    txtField1.Text = strRecord.Substring(0, intIndex)
                Case 2
                    txtField2.Text = strRecord.Substring(0, intIndex)
                Case 3
                    txtField3.Text = strRecord.Substring(0, intIndex)
                Case 4
                    txtField4.Text = strRecord.Substring(0, intIndex)
                Case 5
                    txtField5.Text = strRecord.Substring(0, intIndex)

            End Select

            strRecord = strRecord.Remove(0, intIndex + 1)
            intCount += 1
            strRecord = strRecord.Trim
            intIndex = strRecord.IndexOf(",")

        Loop

        txtField6.Text = strRecord.Substring(0)


    End Sub



    Private Sub txtExit_Click(sender As Object, e As EventArgs) Handles txtExit.Click
        Close()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clearing all textboxes/label

        txtField1.Clear()
        txtField2.Clear()
        txtField3.Clear()
        txtField4.Clear()
        txtField5.Clear()
        txtField6.Clear()
        txtPhoneNumber.Clear()
        txtRecord.Clear()
        txtSentence.Clear()
        lblFormatedPhone.ResetText()

        txtSentence.Focus()
    End Sub

    Private Sub btnPhoneNumber_Click(sender As Object, e As EventArgs) Handles btnPhoneNumber.Click
        'phone number button click to format phone #

        Dim strPhone As String


        Dim blnValidated As Boolean = True

        Validate_PhoneNumber(strPhone, blnValidated)

        If blnValidated Then
            FormatPhoneNumber(strPhone)
        End If


    End Sub

    Private Sub Validate_PhoneNumber(ByRef strPhone As String, ByRef blnValidated As Boolean)
        'validating phone number input

        If txtPhoneNumber.Text = "" Then
            MessageBox.Show("Phone Number Must be Provided")
            txtRecord.Focus()
            blnValidated = False
        Else
            strPhone = txtPhoneNumber.Text
        End If
    End Sub

    Private Sub FormatPhoneNumber(ByVal strPhone As String)
        'format the phone number as assignment says

        strPhone = strPhone.Insert(0, "(")
        strPhone = strPhone.Insert(4, ")")
        strPhone = strPhone.Insert(8, "-")

        lblFormatedPhone.Text = strPhone


    End Sub
End Class
