﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtSentence = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnWords = New System.Windows.Forms.Button()
        Me.btnVowels = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnBreakApart = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtField6 = New System.Windows.Forms.TextBox()
        Me.txtField5 = New System.Windows.Forms.TextBox()
        Me.txtField4 = New System.Windows.Forms.TextBox()
        Me.txtField3 = New System.Windows.Forms.TextBox()
        Me.txtField2 = New System.Windows.Forms.TextBox()
        Me.txtField1 = New System.Windows.Forms.TextBox()
        Me.txtRecord = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnPhoneNumber = New System.Windows.Forms.Button()
        Me.lblFormatedPhone = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtPhoneNumber = New System.Windows.Forms.TextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.txtExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtSentence)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.btnWords)
        Me.GroupBox1.Controls.Add(Me.btnVowels)
        Me.GroupBox1.Location = New System.Drawing.Point(73, 44)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Size = New System.Drawing.Size(519, 138)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Step 1"
        '
        'txtSentence
        '
        Me.txtSentence.Location = New System.Drawing.Point(111, 32)
        Me.txtSentence.Margin = New System.Windows.Forms.Padding(1)
        Me.txtSentence.Name = "txtSentence"
        Me.txtSentence.Size = New System.Drawing.Size(347, 22)
        Me.txtSentence.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 36)
        Me.Label1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Sentence:"
        '
        'btnWords
        '
        Me.btnWords.Location = New System.Drawing.Point(297, 87)
        Me.btnWords.Margin = New System.Windows.Forms.Padding(1)
        Me.btnWords.Name = "btnWords"
        Me.btnWords.Size = New System.Drawing.Size(119, 34)
        Me.btnWords.TabIndex = 2
        Me.btnWords.Text = "Count Words"
        Me.btnWords.UseVisualStyleBackColor = True
        '
        'btnVowels
        '
        Me.btnVowels.Location = New System.Drawing.Point(105, 87)
        Me.btnVowels.Margin = New System.Windows.Forms.Padding(1)
        Me.btnVowels.Name = "btnVowels"
        Me.btnVowels.Size = New System.Drawing.Size(119, 34)
        Me.btnVowels.TabIndex = 1
        Me.btnVowels.Text = "Count Vowels"
        Me.btnVowels.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnBreakApart)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtField6)
        Me.GroupBox2.Controls.Add(Me.txtField5)
        Me.GroupBox2.Controls.Add(Me.txtField4)
        Me.GroupBox2.Controls.Add(Me.txtField3)
        Me.GroupBox2.Controls.Add(Me.txtField2)
        Me.GroupBox2.Controls.Add(Me.txtField1)
        Me.GroupBox2.Controls.Add(Me.txtRecord)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(77, 211)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Size = New System.Drawing.Size(515, 291)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Step 2"
        '
        'btnBreakApart
        '
        Me.btnBreakApart.Location = New System.Drawing.Point(189, 85)
        Me.btnBreakApart.Margin = New System.Windows.Forms.Padding(1)
        Me.btnBreakApart.Name = "btnBreakApart"
        Me.btnBreakApart.Size = New System.Drawing.Size(122, 31)
        Me.btnBreakApart.TabIndex = 14
        Me.btnBreakApart.Text = "Break Apart"
        Me.btnBreakApart.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(281, 248)
        Me.Label8.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 17)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Field 6:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(281, 199)
        Me.Label7.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 17)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Field 5:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(281, 154)
        Me.Label6.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 17)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Field 4:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(31, 248)
        Me.Label5.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 17)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Field 3:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 201)
        Me.Label4.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 17)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Field 2:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 154)
        Me.Label3.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Field 1:"
        '
        'txtField6
        '
        Me.txtField6.Location = New System.Drawing.Point(348, 245)
        Me.txtField6.Margin = New System.Windows.Forms.Padding(1)
        Me.txtField6.Name = "txtField6"
        Me.txtField6.Size = New System.Drawing.Size(108, 22)
        Me.txtField6.TabIndex = 7
        '
        'txtField5
        '
        Me.txtField5.Location = New System.Drawing.Point(348, 198)
        Me.txtField5.Margin = New System.Windows.Forms.Padding(1)
        Me.txtField5.Name = "txtField5"
        Me.txtField5.Size = New System.Drawing.Size(108, 22)
        Me.txtField5.TabIndex = 6
        '
        'txtField4
        '
        Me.txtField4.Location = New System.Drawing.Point(348, 151)
        Me.txtField4.Margin = New System.Windows.Forms.Padding(1)
        Me.txtField4.Name = "txtField4"
        Me.txtField4.Size = New System.Drawing.Size(108, 22)
        Me.txtField4.TabIndex = 5
        '
        'txtField3
        '
        Me.txtField3.Location = New System.Drawing.Point(96, 245)
        Me.txtField3.Margin = New System.Windows.Forms.Padding(1)
        Me.txtField3.Name = "txtField3"
        Me.txtField3.Size = New System.Drawing.Size(108, 22)
        Me.txtField3.TabIndex = 4
        '
        'txtField2
        '
        Me.txtField2.Location = New System.Drawing.Point(96, 198)
        Me.txtField2.Margin = New System.Windows.Forms.Padding(1)
        Me.txtField2.Name = "txtField2"
        Me.txtField2.Size = New System.Drawing.Size(108, 22)
        Me.txtField2.TabIndex = 3
        '
        'txtField1
        '
        Me.txtField1.Location = New System.Drawing.Point(96, 151)
        Me.txtField1.Margin = New System.Windows.Forms.Padding(1)
        Me.txtField1.Name = "txtField1"
        Me.txtField1.Size = New System.Drawing.Size(108, 22)
        Me.txtField1.TabIndex = 2
        '
        'txtRecord
        '
        Me.txtRecord.Location = New System.Drawing.Point(106, 46)
        Me.txtRecord.Margin = New System.Windows.Forms.Padding(1)
        Me.txtRecord.Name = "txtRecord"
        Me.txtRecord.Size = New System.Drawing.Size(347, 22)
        Me.txtRecord.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 49)
        Me.Label2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Record:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnPhoneNumber)
        Me.GroupBox3.Controls.Add(Me.lblFormatedPhone)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.txtPhoneNumber)
        Me.GroupBox3.Location = New System.Drawing.Point(77, 524)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox3.Size = New System.Drawing.Size(515, 156)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Step 3"
        '
        'btnPhoneNumber
        '
        Me.btnPhoneNumber.Location = New System.Drawing.Point(176, 112)
        Me.btnPhoneNumber.Margin = New System.Windows.Forms.Padding(1)
        Me.btnPhoneNumber.Name = "btnPhoneNumber"
        Me.btnPhoneNumber.Size = New System.Drawing.Size(160, 33)
        Me.btnPhoneNumber.TabIndex = 4
        Me.btnPhoneNumber.Text = "Format Phone Number"
        Me.btnPhoneNumber.UseVisualStyleBackColor = True
        '
        'lblFormatedPhone
        '
        Me.lblFormatedPhone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFormatedPhone.Location = New System.Drawing.Point(216, 74)
        Me.lblFormatedPhone.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.lblFormatedPhone.Name = "lblFormatedPhone"
        Me.lblFormatedPhone.Size = New System.Drawing.Size(160, 21)
        Me.lblFormatedPhone.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(31, 33)
        Me.Label10.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(107, 17)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Phone Number:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(33, 74)
        Me.Label9.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(171, 17)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Formated Phone Number:"
        '
        'txtPhoneNumber
        '
        Me.txtPhoneNumber.Location = New System.Drawing.Point(216, 33)
        Me.txtPhoneNumber.Margin = New System.Windows.Forms.Padding(1)
        Me.txtPhoneNumber.Name = "txtPhoneNumber"
        Me.txtPhoneNumber.Size = New System.Drawing.Size(162, 22)
        Me.txtPhoneNumber.TabIndex = 0
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(124, 693)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(1)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(122, 38)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'txtExit
        '
        Me.txtExit.Location = New System.Drawing.Point(389, 695)
        Me.txtExit.Margin = New System.Windows.Forms.Padding(1)
        Me.txtExit.Name = "txtExit"
        Me.txtExit.Size = New System.Drawing.Size(122, 36)
        Me.txtExit.TabIndex = 6
        Me.txtExit.Text = "Exit"
        Me.txtExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(680, 741)
        Me.Controls.Add(Me.txtExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "String Manipulation"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtSentence As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnWords As Button
    Friend WithEvents btnVowels As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnBreakApart As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtField6 As TextBox
    Friend WithEvents txtField5 As TextBox
    Friend WithEvents txtField4 As TextBox
    Friend WithEvents txtField3 As TextBox
    Friend WithEvents txtField2 As TextBox
    Friend WithEvents txtField1 As TextBox
    Friend WithEvents txtRecord As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnPhoneNumber As Button
    Friend WithEvents lblFormatedPhone As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtPhoneNumber As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents txtExit As Button
End Class
